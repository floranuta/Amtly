import type { LucideIcon } from 'lucide-react-native';
import { ArrowLeft, ArrowRight, Check, ChevronDown, Languages } from 'lucide-react-native';
import {
  Button,
  Dialog,
  PressableFeedback,
  SearchField,
  Typography,
  useThemeColor,
} from 'heroui-native';
import type { ReactNode } from 'react';
import { useMemo, useState } from 'react';
import { ScrollView, View } from 'react-native';

import { goBackOrReplace } from '@/lib/navigation';
import {
  LANGUAGES,
  LANGUAGE_ENGLISH_LABELS,
  LANGUAGE_LABELS,
  RTL_LANGUAGES,
  type Language,
  useT,
} from '@/lib/i18n';
import { useAmtlyStore } from '@/lib/amtly-store';

type ActionCardProps = {
  icon: LucideIcon;
  iconTone?: 'red' | 'gold' | 'ink';
  title: string;
  description: string;
  onPress: () => void;
};

const iconToneClasses = {
  red: 'bg-flag-red-soft',
  gold: 'bg-flag-gold-soft',
  ink: 'bg-paper-soft',
};

export function AmtlyBrand() {
  const t = useT();

  return (
    <View className="gap-1">
      <View className="flex-row items-center gap-3">
        <Typography.Heading type="h2" className="text-ink tracking-tight">
          Amtly
        </Typography.Heading>
        <View className="h-1.5 w-12 flex-row overflow-hidden rounded-full">
          <View className="bg-ink flex-1" />
          <View className="bg-flag-red flex-1" />
          <View className="bg-flag-gold flex-1" />
        </View>
      </View>
      <Typography type="body-sm" color="muted">
        {t('tagline')}
      </Typography>
    </View>
  );
}

export function LanguagePicker({ compact = false }: { compact?: boolean }) {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const language = useAmtlyStore((state) => state.language);
  const setLanguage = useAmtlyStore((state) => state.setLanguage);
  const foreground = useThemeColor('foreground');
  const t = useT();
  const isRtl = RTL_LANGUAGES.includes(language);

  const filteredLanguages = useMemo(() => {
    const cleanQuery = query.trim().toLocaleLowerCase();
    if (!cleanQuery) return LANGUAGES;
    return LANGUAGES.filter((id) =>
      `${LANGUAGE_LABELS[id]} ${LANGUAGE_ENGLISH_LABELS[id]}`
        .toLocaleLowerCase()
        .includes(cleanQuery),
    );
  }, [query]);

  const chooseLanguage = (nextLanguage: Language) => {
    setLanguage(nextLanguage);
    setQuery('');
    setIsOpen(false);
  };

  return (
    <Dialog
      isOpen={isOpen}
      onOpenChange={(open) => {
        setIsOpen(open);
        if (!open) setQuery('');
      }}
    >
      <Dialog.Trigger asChild>
        <Button
          variant="secondary"
          size="sm"
          className={
            compact ? 'h-11 min-w-20 self-start rounded-full px-4' : 'self-start rounded-full px-4'
          }
          accessibilityLabel={`${t('languageTitle')}: ${LANGUAGE_LABELS[language]}`}
        >
          {compact ? null : <Languages color={foreground} size={17} />}
          <Button.Label>
            {compact ? language.toUpperCase() : LANGUAGE_LABELS[language]}
          </Button.Label>
          {compact ? <ChevronDown color={foreground} size={16} strokeWidth={2.5} /> : null}
        </Button>
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay />
        <Dialog.Content className="max-h-[85%] gap-4">
          <Dialog.Close variant="ghost" />
          <View className={`gap-1 ${isRtl ? 'pl-10' : 'pr-10'}`}>
            <Dialog.Title>{t('languageTitle')}</Dialog.Title>
            <Dialog.Description>{t('languageDescription')}</Dialog.Description>
          </View>
          <SearchField value={query} onChange={setQuery}>
            <SearchField.Group>
              <SearchField.SearchIcon />
              <SearchField.Input
                placeholder={t('languageSearch')}
                autoFocus
                style={{ textAlign: isRtl ? 'right' : 'left' }}
              />
              <SearchField.ClearButton />
            </SearchField.Group>
          </SearchField>
          <ScrollView keyboardShouldPersistTaps="handled" className="min-h-0">
            <View className="gap-1 pb-2">
              {filteredLanguages.map((id) => (
                <Button
                  key={id}
                  variant="ghost"
                  onPress={() => chooseLanguage(id)}
                  className="min-h-12 justify-start px-3"
                  accessibilityState={{ selected: language === id }}
                >
                  <View
                    className={`min-w-0 flex-1 items-center justify-between gap-3 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}
                  >
                    <View className="min-w-0 flex-1">
                      <Typography weight="semibold" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                        {LANGUAGE_LABELS[id]}
                      </Typography>
                      {LANGUAGE_LABELS[id] !== LANGUAGE_ENGLISH_LABELS[id] ? (
                        <Typography
                          type="body-xs"
                          color="muted"
                          style={{ textAlign: isRtl ? 'right' : 'left' }}
                        >
                          {LANGUAGE_ENGLISH_LABELS[id]}
                        </Typography>
                      ) : null}
                    </View>
                    {language === id ? <Check color={foreground} size={18} /> : null}
                  </View>
                </Button>
              ))}
              {filteredLanguages.length === 0 ? (
                <Typography color="muted" align="center" className="py-8">
                  {t('languageEmpty')}
                </Typography>
              ) : null}
            </View>
          </ScrollView>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog>
  );
}

export function ActionCard({
  icon: Icon,
  iconTone = 'red',
  title,
  description,
  onPress,
}: ActionCardProps) {
  const foreground = useThemeColor('foreground');
  const language = useAmtlyStore((state) => state.language);
  const isRtl = RTL_LANGUAGES.includes(language);

  return (
    <PressableFeedback onPress={onPress} className="overflow-hidden rounded-3xl">
      <View
        className={`border-hairline bg-paper min-h-32 items-center gap-4 rounded-3xl border p-5 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}
      >
        <View
          className={`${iconToneClasses[iconTone]} h-12 w-12 shrink-0 items-center justify-center rounded-2xl`}
        >
          <Icon color={foreground} size={22} strokeWidth={1.8} />
        </View>
        <View className="min-w-0 flex-1 gap-1">
          <Typography
            weight="semibold"
            className="text-ink"
            style={{ textAlign: isRtl ? 'right' : 'left' }}
          >
            {title}
          </Typography>
          <Typography
            type="body-sm"
            color="muted"
            className="leading-5"
            style={{ textAlign: isRtl ? 'right' : 'left' }}
          >
            {description}
          </Typography>
        </View>
      </View>
    </PressableFeedback>
  );
}

type FlowHeaderProps = {
  title: string;
  fallback?: '/';
};

export function FlowHeader({ title, fallback = '/' }: FlowHeaderProps) {
  const foreground = useThemeColor('foreground');
  const language = useAmtlyStore((state) => state.language);
  const t = useT();
  const isRtl = RTL_LANGUAGES.includes(language);
  const BackIcon = isRtl ? ArrowRight : ArrowLeft;

  return (
    <View className={`items-center gap-3 py-3 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
      <Button
        isIconOnly
        variant="ghost"
        accessibilityLabel={t('goBack')}
        onPress={() => goBackOrReplace(fallback)}
        className="rounded-full"
      >
        <BackIcon color={foreground} size={21} />
      </Button>
      <Typography weight="semibold" className="text-ink">
        {title}
      </Typography>
    </View>
  );
}

export function ResultSection({ title, children }: { title: string; children: ReactNode }) {
  const language = useAmtlyStore((state) => state.language);
  const isRtl = RTL_LANGUAGES.includes(language);

  return (
    <View className="border-hairline gap-3 border-b py-6">
      <Typography.Heading
        type="h4"
        className="text-ink"
        style={{ textAlign: isRtl ? 'right' : 'left' }}
      >
        {title}
      </Typography.Heading>
      {typeof children === 'string' ? (
        <Typography
          color="muted"
          className="leading-6"
          style={{ textAlign: isRtl ? 'right' : 'left' }}
        >
          {children}
        </Typography>
      ) : (
        children
      )}
    </View>
  );
}
