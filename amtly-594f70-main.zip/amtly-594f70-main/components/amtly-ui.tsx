import type { LucideIcon } from 'lucide-react-native';
import { ChevronRight } from 'lucide-react-native';
import type { ReactNode } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { PressableFeedback, Typography, useThemeColor } from 'heroui-native';

import { Path, Svg } from '@/components/ui/primitives/Svg';

type Tone = 'red' | 'gold' | 'blue' | 'neutral' | 'green';

const toneClasses: Record<Tone, string> = {
  red: 'bg-flag-red-soft',
  gold: 'bg-flag-gold-soft',
  blue: 'bg-info-soft',
  neutral: 'bg-paper-soft',
  green: 'bg-success-soft',
};

export function AmtlyLogo({ large = false }: { large?: boolean }) {
  const { width } = useWindowDimensions();
  const titleSize = large ? (width < 360 ? 58 : 68) : 42;
  const titleLineHeight = Math.round(titleSize * 0.96);
  const tracking = large ? -3.6 : -2.5;
  const accentJoin = large ? -2.5 : -1.75;

  return (
    <View className={large ? 'items-center' : undefined}>
      <View className="flex-row items-baseline" accessibilityLabel="Amtly">
        <Typography.Heading
          type={large ? 'h1' : 'h2'}
          className="text-ink font-black"
          style={{ fontSize: titleSize, lineHeight: titleLineHeight, letterSpacing: tracking }}
        >
          Amt
        </Typography.Heading>
        <Typography.Heading
          type={large ? 'h1' : 'h2'}
          className="text-flag-red font-black"
          style={{
            fontSize: titleSize,
            lineHeight: titleLineHeight,
            letterSpacing: tracking,
            marginLeft: accentJoin,
          }}
        >
          l
        </Typography.Heading>
        <Typography.Heading
          type={large ? 'h1' : 'h2'}
          className="text-flag-gold font-black"
          style={{
            fontSize: titleSize,
            lineHeight: titleLineHeight,
            letterSpacing: tracking,
            marginLeft: accentJoin,
          }}
        >
          y
        </Typography.Heading>
      </View>
      <Typography
        align={large ? 'center' : 'start'}
        className={large ? 'mt-2 tracking-[0.15px]' : 'mt-1'}
      >
        Germany, made simpler.
      </Typography>
    </View>
  );
}

export function BerlinFlagArtwork() {
  return (
    <View className="w-full overflow-hidden" style={{ aspectRatio: 1.42 }}>
      <Svg width="100%" height="100%" viewBox="0 0 420 296" preserveAspectRatio="xMidYMid meet">
        <Path
          fillClassName="fill-hairline"
          d="M92 170h18v-17h14v17h13v-35h23v35h12v-49h25v49h16v-28h14v28h11v25H92z"
        />
        <Path
          fillClassName="fill-ink"
          d="M0 148c54 5 82 33 132 40 41 6 75 2 109 11 58 16 112 19 179 5v92H0z"
        />
        <Path
          fillClassName="fill-ink"
          d="M198 151h99v9h-99zm6-8h87l-7-6h-73zm7 17h8v47h-8zm22 0h8v50h-8zm22 0h8v53h-8zm22 0h8v53h-8zm-72-17 7-8h72l7 8zm35-18 3-3 3 3v10h-6zm7-2 3-4 3 4v12h-6zm7 2 3-3 3 3v10h-6zm-12-6 3-6 3 6zm7-4 3-7 3 7zm7 4 3-6 3 6z"
        />
        <Path
          fillClassName="fill-ink"
          d="M309 179h15v-35l9-8 9 8v35h13v-73h5v73h10V69h3V31h3v38h3v12c8 3 13 10 13 19 0 7-4 13-10 17l7 61h13v-39h17v39h12v35H309zm58-79a9 9 0 1 0 18 0 9 9 0 0 0-18 0z"
        />
        <Path
          fillClassName="fill-flag-red"
          d="M0 210c81 10 116-17 181-22 82-7 129 23 239 37v71H0z"
        />
        <Path
          fillClassName="fill-flag-gold"
          d="M0 259c87 19 139-1 203-30 68-30 125-26 217-3v70H0z"
        />
        <Path fillClassName="fill-paper" d="M0 281c78 18 143 4 211-27 73-33 132-33 209-15v57H0z" />
      </Svg>
    </View>
  );
}

export function SoftIcon({
  icon: Icon,
  tone = 'neutral',
  size = 42,
}: {
  icon: LucideIcon;
  tone?: Tone;
  size?: number;
}) {
  const foreground = useThemeColor('foreground');
  return (
    <View
      className={`${toneClasses[tone]} items-center justify-center rounded-2xl`}
      style={{ width: size, height: size }}
    >
      <Icon color={foreground} size={size * 0.48} strokeWidth={2} />
    </View>
  );
}

export function FeatureCard({
  icon,
  tone,
  title,
  body,
  onPress,
}: {
  icon: LucideIcon;
  tone: Tone;
  title: string;
  body: string;
  onPress: () => void;
}) {
  return (
    <PressableFeedback onPress={onPress} className="flex-1 overflow-hidden rounded-3xl">
      <View className={`${toneClasses[tone]} min-h-44 flex-1 gap-3 rounded-3xl p-4`}>
        <SoftIcon icon={icon} tone={tone} />
        <View className="gap-1">
          <Typography weight="bold" className="text-ink text-lg leading-5">
            {title}
          </Typography>
          <Typography type="body-xs" className="text-ink-muted leading-4">
            {body}
          </Typography>
        </View>
      </View>
    </PressableFeedback>
  );
}

export function NumberedCard({
  number,
  title,
  body,
  onPress,
}: {
  number: number;
  title: string;
  body: string;
  onPress: () => void;
}) {
  const foreground = useThemeColor('foreground');
  return (
    <PressableFeedback onPress={onPress} className="overflow-hidden rounded-2xl">
      <View className="border-hairline bg-paper flex-row items-center gap-4 rounded-2xl border p-4 shadow-sm">
        <View className="bg-flag-red h-9 w-9 items-center justify-center rounded-full">
          <Typography weight="bold" className="text-paper">
            {number}
          </Typography>
        </View>
        <View className="min-w-0 flex-1 gap-1">
          <Typography weight="bold" className="text-ink">
            {title}
          </Typography>
          <Typography type="body-sm" color="muted" className="leading-5">
            {body}
          </Typography>
        </View>
        <ChevronRight color={foreground} size={18} />
      </View>
    </PressableFeedback>
  );
}

export function InfoRow({
  icon,
  title,
  children,
  action,
}: {
  icon: LucideIcon;
  title: string;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <View className="flex-row items-start gap-4 py-4">
      <SoftIcon icon={icon} size={38} />
      <View className="min-w-0 flex-1 gap-1">
        <Typography weight="bold" className="text-ink">
          {title}
        </Typography>
        {typeof children === 'string' ? (
          <Typography type="body-sm" className="text-ink-muted leading-5">
            {children}
          </Typography>
        ) : (
          children
        )}
      </View>
      {action}
    </View>
  );
}

export function StatusPill({
  label,
  tone = 'neutral',
}: {
  label: string;
  tone?: 'red' | 'gold' | 'neutral' | 'green';
}) {
  return (
    <View className={`${toneClasses[tone]} self-start rounded-full px-2.5 py-1`}>
      <Typography
        type="body-xs"
        weight="semibold"
        className={tone === 'red' ? 'text-flag-red' : 'text-ink-muted'}
      >
        {label}
      </Typography>
    </View>
  );
}
