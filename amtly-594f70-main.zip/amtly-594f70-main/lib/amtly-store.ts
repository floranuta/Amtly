import { create } from 'zustand';

import type { Language } from '@/lib/i18n';

export type AmtlyLanguage = Language;

export type UploadedDocument = {
  name: string;
  uri: string;
  mimeType?: string | null;
};

type AmtlyState = {
  language: AmtlyLanguage;
  question: string;
  document: UploadedDocument | null;
  savedRegistration: boolean;
  completedTaskIds: string[];
  setLanguage: (language: AmtlyLanguage) => void;
  setQuestion: (question: string) => void;
  setDocument: (document: UploadedDocument | null) => void;
  saveRegistration: () => void;
  toggleTask: (taskId: string) => void;
};

export const useAmtlyStore = create<AmtlyState>((set) => ({
  language: 'en',
  question: '',
  document: null,
  savedRegistration: false,
  completedTaskIds: [],
  setLanguage: (language) => set({ language }),
  setQuestion: (question) => set({ question }),
  setDocument: (document) => set({ document }),
  saveRegistration: () => set({ savedRegistration: true }),
  toggleTask: (taskId) =>
    set((state) => ({
      completedTaskIds: state.completedTaskIds.includes(taskId)
        ? state.completedTaskIds.filter((id) => id !== taskId)
        : [...state.completedTaskIds, taskId],
    })),
}));
