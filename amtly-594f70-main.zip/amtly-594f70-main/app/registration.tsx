import { router } from 'expo-router';
import { Button, Typography, useThemeColor } from 'heroui-native';
import {
  Building2,
  CalendarClock,
  ChevronLeft,
  ClipboardCheck,
  ExternalLink,
  FileCheck2,
  MoreHorizontal,
  ShieldCheck,
} from 'lucide-react-native';
import { Linking, ScrollView, View } from 'react-native';

import { InfoRow, StatusPill } from '@/components/amtly-ui';
import { useAmtlyStore } from '@/lib/amtly-store';

export default function RegistrationScreen() {
  const saveRegistration = useAmtlyStore((state) => state.saveRegistration);
  const saved = useAmtlyStore((state) => state.savedRegistration);
  const foreground = useThemeColor('foreground');
  return (
    <ScrollView
      className="bg-background flex-1"
      contentContainerClassName="p-safe-offset-5 web:mx-auto web:w-full web:max-w-lg"
    >
      <View className="flex-row items-center justify-between py-3">
        <Button isIconOnly variant="ghost" onPress={() => router.back()}>
          <ChevronLeft color={foreground} />
        </Button>
        <Typography weight="bold">Register your address</Typography>
        <Button isIconOnly variant="ghost">
          <MoreHorizontal color={foreground} />
        </Button>
      </View>
      <View className="gap-2 pt-4 pb-10">
        <View className="border-hairline flex-row items-start gap-4 border-b pb-5">
          <View className="bg-flag-red h-11 w-11 items-center justify-center rounded-full">
            <Typography weight="bold" className="text-paper">
              1
            </Typography>
          </View>
          <View className="min-w-0 flex-1 gap-2">
            <Typography.Heading type="h3" className="text-ink">
              Register your address (Anmeldung)
            </Typography.Heading>
            <Typography type="body-sm" color="muted">
              Required for everyone living in Germany for more than 3 months.
            </Typography>
          </View>
        </View>
        <InfoRow icon={ClipboardCheck} title="What you need to do">
          Book an appointment at the Bürgeramt in your city and register your address.
        </InfoRow>
        <InfoRow icon={FileCheck2} title="Required documents">
          <View className="gap-1">
            <Typography type="body-sm">• Passport or ID card</Typography>
            <Typography type="body-sm">• Wohnungsgeberbestätigung</Typography>
            <Typography type="body-sm">• Rental contract</Typography>
          </View>
        </InfoRow>
        <InfoRow icon={Building2} title="Responsible authority">
          Bürgeramt in your city
        </InfoRow>
        <InfoRow icon={CalendarClock} title="Important">
          <View className="gap-2">
            <Typography type="body-sm" color="muted">
              Registration should be completed within two weeks after moving.
            </Typography>
            <StatusPill label="Time-sensitive" tone="red" />
          </View>
        </InfoRow>
        <InfoRow icon={ShieldCheck} title="Official source">
          <Button
            variant="ghost"
            className="h-auto justify-start px-0"
            onPress={() => Linking.openURL('https://verwaltung.bund.de/')}
          >
            <Button.Label>Federal service portal</Button.Label>
            <ExternalLink color={foreground} size={15} />
          </Button>
        </InfoRow>
        <Button
          className="bg-flag-gold mt-4 h-14 rounded-full"
          onPress={() => {
            saveRegistration();
            router.replace('/(tabs)/tasks');
          }}
        >
          <Button.Label className="text-ink">
            {saved ? 'Saved to My Tasks' : 'Save to My Tasks'}
          </Button.Label>
        </Button>
      </View>
    </ScrollView>
  );
}
