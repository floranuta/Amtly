import { router } from 'expo-router';
import { Button } from 'heroui-native';
import { Image, ScrollView, View } from 'react-native';

const welcomeArtwork = require('@/assets/amtly-welcome.png');

const enterApp = () => router.replace('/(tabs)/home');

export default function OnboardingScreen() {
  return (
    <ScrollView
      className="bg-paper flex-1"
      contentContainerClassName="min-h-full p-safe-offset-5 web:mx-auto web:w-full web:max-w-md"
      bounces={false}
    >
      <View className="flex-1 justify-between gap-8 pt-10 pb-5">
        <View className="items-center">
          <Image
            source={welcomeArtwork}
            accessibilityLabel="Amtly — Germany, made simpler, with the Berlin skyline and German flag"
            resizeMode="contain"
            style={{ width: '100%', height: 512 }}
          />
        </View>

        <View className="gap-3 px-1">
          <Button className="bg-ink h-14 rounded-full" onPress={enterApp}>
            <Button.Label className="text-paper font-semibold">Get started</Button.Label>
          </Button>
          <Button variant="ghost" className="h-12 rounded-full" onPress={enterApp}>
            <Button.Label className="text-ink">I already have an account</Button.Label>
          </Button>
        </View>
      </View>
    </ScrollView>
  );
}
