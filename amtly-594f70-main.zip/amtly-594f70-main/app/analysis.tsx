import { router } from 'expo-router';
import { Button, Typography, useThemeColor } from 'heroui-native';
import {
  BriefcaseBusiness,
  CalendarClock,
  ChevronLeft,
  FileCheck2,
  Info,
  ShieldCheck,
} from 'lucide-react-native';
import { ScrollView, View } from 'react-native';

import { InfoRow, StatusPill } from '@/components/amtly-ui';
import { useAmtlyStore } from '@/lib/amtly-store';

export default function AnalysisScreen() {
  const document = useAmtlyStore((state) => state.document);
  const foreground = useThemeColor('foreground');
  return (
    <ScrollView
      className="bg-background flex-1"
      contentContainerClassName="p-safe-offset-5 web:mx-auto web:w-full web:max-w-lg"
    >
      <View className="flex-row items-center gap-3 py-3">
        <Button isIconOnly variant="ghost" onPress={() => router.back()}>
          <ChevronLeft color={foreground} />
        </Button>
        <Typography weight="bold">Letter Analysis</Typography>
      </View>
      <View className="gap-3 pt-3 pb-10">
        <View className="border-hairline bg-paper-soft flex-row items-center gap-3 rounded-2xl border p-4">
          <FileCheck2 color={foreground} size={28} />
          <View className="min-w-0 flex-1">
            <Typography weight="bold">{document?.name ?? 'jobcenter.pdf'}</Typography>
            <Typography type="body-xs" color="muted">
              2 pages · Ready
            </Typography>
          </View>
        </View>
        <View className="bg-success-soft rounded-xl px-4 py-3">
          <Typography type="body-sm" weight="semibold" className="text-ink">
            Analysis complete
          </Typography>
        </View>
        <View className="bg-paper-soft rounded-2xl px-4">
          <InfoRow icon={Info} title="What is this?">
            This is a request from the Jobcenter to provide additional documents for your
            application.
          </InfoRow>
        </View>
        <View className="bg-paper-soft rounded-2xl px-4">
          <InfoRow icon={Info} title="What do they want?">
            Submit your rental contract and service-charge statement.
          </InfoRow>
        </View>
        <View className="bg-paper-soft rounded-2xl px-4">
          <InfoRow icon={CalendarClock} title="Deadline">
            <StatusPill label="5 October 2026" tone="red" />
          </InfoRow>
        </View>
        <View className="bg-paper-soft rounded-2xl px-4">
          <InfoRow icon={ShieldCheck} title="What should you do?">
            <View className="gap-1">
              <Typography type="body-sm">1. Collect the requested documents</Typography>
              <Typography type="body-sm">2. Send them to the Jobcenter</Typography>
              <Typography type="body-sm">3. Keep proof of submission</Typography>
            </View>
          </InfoRow>
        </View>
        <View className="bg-paper-soft rounded-2xl px-4">
          <InfoRow icon={BriefcaseBusiness} title="Required documents">
            <View>
              <Typography type="body-sm">• Mietvertrag</Typography>
              <Typography type="body-sm">• Nebenkostenabrechnung</Typography>
            </View>
          </InfoRow>
        </View>
        <Button
          className="bg-flag-gold mt-2 h-14 rounded-full"
          onPress={() =>
            router.push({
              pathname: '/ask',
              params: { prompt: 'Help me prepare a reply to the Jobcenter.' },
            })
          }
        >
          <Button.Label className="text-ink">Prepare my reply</Button.Label>
        </Button>
      </View>
    </ScrollView>
  );
}
