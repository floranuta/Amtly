import {
  Building2,
  CalendarClock,
  Check,
  ExternalLink,
  FileCheck2,
  ListChecks,
} from 'lucide-react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Button, Typography, useThemeColor } from 'heroui-native';
import { Linking, ScrollView, View } from 'react-native';

import { FlowHeader, ResultSection } from '@/components/amtly';
import { useAmtlyStore } from '@/lib/amtly-store';
import { RTL_LANGUAGES, useT } from '@/lib/i18n';

function Bullet({ children }: { children: string }) {
  const accent = useThemeColor('accent');
  const language = useAmtlyStore((state) => state.language);
  const isRtl = RTL_LANGUAGES.includes(language);
  return (
    <View className={`gap-3 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
      <View className="bg-flag-red-soft mt-0.5 h-6 w-6 shrink-0 items-center justify-center rounded-full">
        <Check color={accent} size={14} strokeWidth={2.5} />
      </View>
      <Typography
        color="muted"
        className="min-w-0 flex-1 leading-6"
        style={{ textAlign: isRtl ? 'right' : 'left' }}
      >
        {children}
      </Typography>
    </View>
  );
}

export default function ResultsScreen() {
  const { mode } = useLocalSearchParams<{ mode?: 'question' | 'document' | 'authority' }>();
  const language = useAmtlyStore((state) => state.language);
  const setQuestion = useAmtlyStore((state) => state.setQuestion);
  const t = useT();
  const foreground = useThemeColor('foreground');
  const isRtl = RTL_LANGUAGES.includes(language);

  const summary =
    mode === 'document'
      ? t('summaryDocument').replace('{name}', t('uploadImageName'))
      : mode === 'authority'
        ? t('summaryAuthority')
        : t('summaryFallback');

  const prepareReply = () => {
    const prompt = t('replyPrompt').replace('{document}', '');
    setQuestion(prompt);
    router.replace({ pathname: '/(tabs)/home', params: { prompt } });
  };

  return (
    <ScrollView
      className="bg-background flex-1"
      contentContainerClassName="p-safe-offset-5 web:mx-auto web:w-full web:max-w-3xl"
    >
      <FlowHeader title={t('resultHeader')} />
      <View className="pt-5 pb-12">
        <View className="bg-ink mb-2 gap-3 rounded-3xl p-6">
          <Typography type="body-sm" className="text-flag-gold" weight="semibold">
            {t('resultEyebrow')}
          </Typography>
          <Typography.Heading type="h2" className="text-paper tracking-tight">
            {t('resultTitle')}
          </Typography.Heading>
          <Typography className="text-paper/80 leading-6">{summary}</Typography>
        </View>

        <ResultSection title={t('sSummary')}>{summary}</ResultSection>

        <ResultSection title={t('sWhatToDo')}>
          <View className="gap-3">
            <Bullet>{t('taskOne')}</Bullet>
            <Bullet>{t('taskTwo')}</Bullet>
            <Bullet>{t('taskThree')}</Bullet>
          </View>
        </ResultSection>

        <ResultSection title={t('sNextSteps')}>
          <View className="gap-3">
            <Bullet>{t('nextOne')}</Bullet>
            <Bullet>{t('nextTwo')}</Bullet>
            <Bullet>{t('nextThree')}</Bullet>
          </View>
        </ResultSection>

        <ResultSection title={t('sDocuments')}>
          <View className={`gap-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
            <View className="bg-paper-soft h-11 w-11 items-center justify-center rounded-2xl">
              <FileCheck2 color={foreground} size={21} />
            </View>
            <View className="min-w-0 flex-1 gap-1">
              <Typography color="muted" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                • {t('documentOne')}
              </Typography>
              <Typography color="muted" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                • {t('documentTwo')}
              </Typography>
              <Typography color="muted" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                • {t('documentThree')}
              </Typography>
            </View>
          </View>
        </ResultSection>

        <ResultSection title={t('sAuthority')}>
          <View className={`gap-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
            <View className="bg-paper-soft h-11 w-11 items-center justify-center rounded-2xl">
              <Building2 color={foreground} size={21} />
            </View>
            <View className="min-w-0 flex-1 gap-1">
              <Typography
                weight="semibold"
                className="text-ink"
                style={{ textAlign: isRtl ? 'right' : 'left' }}
              >
                {t('authorityName')}
              </Typography>
              <Typography
                color="muted"
                className="leading-6"
                style={{ textAlign: isRtl ? 'right' : 'left' }}
              >
                {t('authorityBody')}
              </Typography>
            </View>
          </View>
        </ResultSection>

        <ResultSection title={t('sDeadlines')}>
          <View className={`gap-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
            <View className="bg-flag-gold-soft h-11 w-11 items-center justify-center rounded-2xl">
              <CalendarClock color={foreground} size={21} />
            </View>
            <Typography
              color="muted"
              className="min-w-0 flex-1 leading-6"
              style={{ textAlign: isRtl ? 'right' : 'left' }}
            >
              {t('deadlineBody')}
            </Typography>
          </View>
        </ResultSection>

        <ResultSection title={t('sSources')}>
          <View className="gap-3">
            <Button
              variant="ghost"
              className="justify-start px-0"
              onPress={() => Linking.openURL('https://verwaltung.bund.de/')}
            >
              <ListChecks color={foreground} size={18} />
              <Button.Label>{t('sourceFederal')}</Button.Label>
              <ExternalLink color={foreground} size={16} />
            </Button>
            <Button
              variant="ghost"
              className="justify-start px-0"
              onPress={() => Linking.openURL('https://www.make-it-in-germany.com/')}
            >
              <Building2 color={foreground} size={18} />
              <Button.Label>{t('sourceGermany')}</Button.Label>
              <ExternalLink color={foreground} size={16} />
            </Button>
          </View>
        </ResultSection>

        <View className="gap-3 pt-8">
          <Button onPress={prepareReply}>
            <Button.Label>{t('prepareReply')}</Button.Label>
          </Button>
          <Button variant="secondary" onPress={() => router.replace('/(tabs)/home')}>
            <Button.Label>{t('askAnother')}</Button.Label>
          </Button>
        </View>
      </View>
    </ScrollView>
  );
}
