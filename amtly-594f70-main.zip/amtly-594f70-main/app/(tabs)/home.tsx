import { router } from 'expo-router';
import { Button, FieldError, TextArea, TextField, Typography, useThemeColor } from 'heroui-native';
import { FileText, MapPin, MessageCircle, Mic, Users } from 'lucide-react-native';
import { useState } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';

import { AmtlyLogo, FeatureCard } from '@/components/amtly-ui';
import { LanguagePicker } from '@/components/amtly';
import { useAmtlyStore } from '@/lib/amtly-store';

export default function HomeScreen() {
  const storedQuestion = useAmtlyStore((state) => state.question);
  const setStoredQuestion = useAmtlyStore((state) => state.setQuestion);
  const [question, setQuestion] = useState(storedQuestion);
  const [invalid, setInvalid] = useState(false);
  const foreground = useThemeColor('foreground');
  const startAsk = (prompt = question) => {
    const clean = prompt.trim();
    if (!clean) {
      setInvalid(true);
      return;
    }
    setStoredQuestion(clean);
    setInvalid(false);
    router.push('/ask');
  };
  return (
    <KeyboardAvoidingView
      className="bg-background flex-1"
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerClassName="p-safe-offset-5 web:mx-auto web:w-full web:max-w-lg"
      >
        <View className="pt-2 pb-8">
          <View className="-mx-4">
            <View className="flex-row items-start justify-between">
              <AmtlyLogo />
              <LanguagePicker compact />
            </View>

            <View className="mt-11 gap-0">
              <Typography.Heading
                type="h1"
                className="text-ink font-black tracking-tighter"
                style={{ fontSize: 31, lineHeight: 36 }}
              >
                Hi! 👋
              </Typography.Heading>
              <Typography.Heading
                type="h2"
                className="text-ink font-black tracking-tighter"
                style={{ fontSize: 28, lineHeight: 34 }}
              >
                What can I help you with?
              </Typography.Heading>
            </View>

            <TextField isInvalid={invalid} className="mt-6">
              <View className="relative">
                <TextArea
                  value={question}
                  onChangeText={setQuestion}
                  placeholder="Describe your situation..."
                  className="rounded-3xl py-4 pr-14 pl-5"
                  style={{ minHeight: 72 }}
                />
                <Button
                  isIconOnly
                  variant="ghost"
                  className="absolute top-3.5 right-2 rounded-full"
                  onPress={() => startAsk()}
                >
                  <Mic color={foreground} size={24} strokeWidth={2.5} />
                </Button>
              </View>
              {invalid ? (
                <FieldError>Tell me a little about your situation first.</FieldError>
              ) : null}
            </TextField>
          </View>

          <View className="mt-7 gap-3">
            <View className="flex-row gap-3">
              <FeatureCard
                icon={MessageCircle}
                tone="red"
                title="Ask Amtly"
                body="Tell me your situation and I’ll guide you through the next steps."
                onPress={() => startAsk(question || 'I moved to Germany. What should I do first?')}
              />
              <FeatureCard
                icon={FileText}
                tone="gold"
                title="Understand a Letter"
                body="Upload an official letter and I’ll explain what it means."
                onPress={() => router.push('/(tabs)/documents')}
              />
            </View>
            <View className="flex-row gap-3">
              <FeatureCard
                icon={MapPin}
                tone="gold"
                title="Find the Right Place"
                body="Find which authority can help you."
                onPress={() => startAsk('Which authority can help with my situation?')}
              />
              <FeatureCard
                icon={Users}
                tone="blue"
                title="I Need Help Now"
                body="Get quick guidance for urgent situations."
                onPress={() => startAsk('I need urgent help with an official process.')}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
