import { Tabs } from 'expo-router';
import { ClipboardCheck, FileText, Home, UserRound } from 'lucide-react-native';
import { StatusBar } from 'react-native';
import { useThemeColor } from 'heroui-native';

export default function TabLayout() {
  const background = useThemeColor('background');
  const border = useThemeColor('border');
  const accent = useThemeColor('accent');
  const muted = useThemeColor('muted');
  return (
    <>
      <StatusBar barStyle="dark-content" />
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: accent,
          tabBarInactiveTintColor: muted,
          tabBarLabelStyle: { fontFamily: 'Inter_500Medium', fontSize: 11 },
          tabBarStyle: {
            backgroundColor: background,
            borderTopColor: border,
            height: 72,
            paddingTop: 8,
            paddingBottom: 8,
            elevation: 0,
            shadowOpacity: 0,
          },
        }}
      >
        <Tabs.Screen
          name="home"
          options={{
            title: 'Home',
            tabBarIcon: ({ color, size }) => <Home color={color} size={size} />,
          }}
        />
        <Tabs.Screen
          name="documents"
          options={{
            title: 'Documents',
            tabBarIcon: ({ color, size }) => <FileText color={color} size={size} />,
          }}
        />
        <Tabs.Screen
          name="tasks"
          options={{
            title: 'My Tasks',
            tabBarIcon: ({ color, size }) => <ClipboardCheck color={color} size={size} />,
          }}
        />
        <Tabs.Screen
          name="profile"
          options={{
            title: 'Profile',
            tabBarIcon: ({ color, size }) => <UserRound color={color} size={size} />,
          }}
        />
      </Tabs>
    </>
  );
}
