import { Button, Typography, useThemeColor } from 'heroui-native';
import { Building2, Check, CheckCircle2, Clock3, ListTodo } from 'lucide-react-native';
import { useMemo, useState } from 'react';
import { ScrollView, View } from 'react-native';

import { StatusPill } from '@/components/amtly-ui';
import { useAmtlyStore } from '@/lib/amtly-store';

type TaskFilter = 'Active' | 'Completed' | 'All';

type TaskItem = {
  id: string;
  title: string;
  place: string;
  status: string;
  helper: string;
  tone: 'red' | 'gold' | 'neutral';
};

const tasks: TaskItem[] = [
  {
    id: 'jobcenter',
    title: 'Send documents to Jobcenter',
    place: 'Jobcenter',
    status: 'Due 5 Oct 2026',
    helper: 'Upload the requested proof of income and tenancy documents.',
    tone: 'red',
  },
  {
    id: 'register',
    title: 'Register your address',
    place: 'Bürgeramt Hamburg',
    status: 'In progress',
    helper: 'Bring your passport and landlord confirmation to the appointment.',
    tone: 'gold',
  },
  {
    id: 'insurance',
    title: 'Check health insurance',
    place: 'Krankenkasse',
    status: 'Not started',
    helper: 'Confirm your coverage and request a membership certificate.',
    tone: 'neutral',
  },
  {
    id: 'licence',
    title: 'Check driving licence',
    place: 'Führerscheinstelle',
    status: 'Not started',
    helper: 'Check whether your current licence needs to be exchanged.',
    tone: 'neutral',
  },
];

const filters: TaskFilter[] = ['Active', 'Completed', 'All'];

export default function TasksScreen() {
  const [filter, setFilter] = useState<TaskFilter>('Active');
  const completed = useAmtlyStore((state) => state.completedTaskIds);
  const toggle = useAmtlyStore((state) => state.toggleTask);
  const foreground = useThemeColor('foreground');
  const mutedForeground = useThemeColor('muted');
  const accentForeground = useThemeColor('accent-foreground');

  const completedCount = tasks.filter((task) => completed.includes(task.id)).length;
  const activeCount = tasks.length - completedCount;
  const progress = tasks.length === 0 ? 0 : Math.round((completedCount / tasks.length) * 100);

  const visible = useMemo(
    () =>
      tasks.filter(
        (task) =>
          filter === 'All' ||
          (filter === 'Completed' ? completed.includes(task.id) : !completed.includes(task.id)),
      ),
    [completed, filter],
  );

  const countFor = (item: TaskFilter) => {
    if (item === 'Active') return activeCount;
    if (item === 'Completed') return completedCount;
    return tasks.length;
  };

  return (
    <View className="bg-background flex-1">
      <ScrollView showsVerticalScrollIndicator={false}>
        <View className="p-safe-offset-5 web:mx-auto web:w-full web:max-w-lg gap-6 pt-3 pb-32">
          <View className="gap-2">
            <Typography
              type="body-xs"
              weight="bold"
              className="text-flag-red tracking-widest uppercase"
            >
              Your plan
            </Typography>
            <Typography.Heading type="h1" className="text-ink tracking-tighter">
              My Tasks
            </Typography.Heading>
            <Typography color="muted" className="max-w-sm leading-6">
              Keep the important paperwork moving, one clear step at a time.
            </Typography>
          </View>

          <View className="bg-ink gap-5 rounded-3xl p-5">
            <View className="flex-row items-start justify-between gap-4">
              <View className="min-w-0 flex-1 gap-1">
                <Typography type="body-sm" weight="semibold" className="text-paper/70">
                  Overall progress
                </Typography>
                <Typography.Heading type="h3" className="text-paper">
                  {completedCount} of {tasks.length} completed
                </Typography.Heading>
              </View>
              <View className="bg-flag-gold h-14 w-14 items-center justify-center rounded-full">
                <Typography weight="bold" className="text-ink text-lg">
                  {progress}%
                </Typography>
              </View>
            </View>
            <View className="bg-paper/20 h-2 overflow-hidden rounded-full">
              <View
                className="bg-flag-gold h-full rounded-full"
                style={{ width: `${progress}%` }}
              />
            </View>
            <View className="flex-row items-center gap-2">
              <Clock3 color={accentForeground} size={16} />
              <Typography type="body-xs" className="text-paper/70">
                {activeCount === 1
                  ? '1 task still needs attention'
                  : `${activeCount} tasks still need attention`}
              </Typography>
            </View>
          </View>

          <View className="bg-paper-soft flex-row gap-1 rounded-2xl p-1.5">
            {filters.map((item) => {
              const selected = filter === item;
              return (
                <Button
                  key={item}
                  size="sm"
                  variant={selected ? 'primary' : 'ghost'}
                  className={`h-11 flex-1 rounded-xl px-2 ${selected ? 'bg-paper shadow-sm' : ''}`}
                  onPress={() => setFilter(item)}
                  accessibilityState={{ selected }}
                >
                  <Button.Label className={selected ? 'text-ink' : 'text-ink-muted'}>
                    {item} {countFor(item)}
                  </Button.Label>
                </Button>
              );
            })}
          </View>

          <View className="gap-3">
            <View className="flex-row items-center justify-between px-1">
              <Typography.Heading type="h4" className="text-ink">
                {filter === 'All' ? 'All tasks' : `${filter} tasks`}
              </Typography.Heading>
              <Typography type="body-xs" color="muted">
                {visible.length} {visible.length === 1 ? 'item' : 'items'}
              </Typography>
            </View>

            {visible.map((task) => {
              const done = completed.includes(task.id);
              return (
                <View
                  key={task.id}
                  className={`border-hairline bg-paper gap-4 rounded-3xl border p-5 shadow-sm ${done ? 'opacity-70' : ''}`}
                >
                  <View className="flex-row items-start gap-3">
                    <View
                      className={`h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${
                        done
                          ? 'bg-success-soft'
                          : task.tone === 'red'
                            ? 'bg-flag-red-soft'
                            : task.tone === 'gold'
                              ? 'bg-flag-gold-soft'
                              : 'bg-paper-soft'
                      }`}
                    >
                      {done ? (
                        <CheckCircle2 color={foreground} size={21} />
                      ) : (
                        <Building2 color={foreground} size={20} />
                      )}
                    </View>
                    <View className="min-w-0 flex-1 gap-1">
                      <Typography
                        weight="bold"
                        className={done ? 'text-ink-muted line-through' : 'text-ink'}
                      >
                        {task.title}
                      </Typography>
                      <Typography type="body-xs" color="muted">
                        {task.place}
                      </Typography>
                    </View>
                    <Button
                      isIconOnly
                      size="sm"
                      variant={done ? 'primary' : 'secondary'}
                      className={`h-10 w-10 rounded-full ${done ? 'bg-ink' : 'border-hairline bg-paper border'}`}
                      onPress={() => toggle(task.id)}
                      accessibilityLabel={
                        done ? `Mark ${task.title} as active` : `Complete ${task.title}`
                      }
                      accessibilityState={{ checked: done }}
                    >
                      {done ? (
                        <Check color={accentForeground} size={17} strokeWidth={3} />
                      ) : (
                        <View className="border-hairline h-4 w-4 rounded-full border-2" />
                      )}
                    </Button>
                  </View>

                  <Typography type="body-sm" color="muted" className="leading-5">
                    {task.helper}
                  </Typography>

                  <View className="border-hairline flex-row items-center justify-between border-t pt-4">
                    <StatusPill
                      label={done ? 'Completed' : task.status}
                      tone={done ? 'green' : task.tone}
                    />
                    <Typography type="body-xs" weight="semibold" color="muted">
                      {done ? 'Done' : 'Tap the circle when done'}
                    </Typography>
                  </View>
                </View>
              );
            })}

            {visible.length === 0 ? (
              <View className="border-hairline bg-paper items-center gap-3 rounded-3xl border border-dashed px-6 py-12">
                <View className="bg-success-soft h-14 w-14 items-center justify-center rounded-full">
                  {filter === 'Completed' ? (
                    <ListTodo color={mutedForeground} size={25} />
                  ) : (
                    <CheckCircle2 color={foreground} size={25} />
                  )}
                </View>
                <Typography weight="bold" className="text-ink">
                  {filter === 'Completed' ? 'Nothing completed yet' : 'You’re all caught up'}
                </Typography>
                <Typography type="body-sm" color="muted" align="center" className="leading-5">
                  {filter === 'Completed'
                    ? 'Completed tasks will appear here.'
                    : 'There are no active tasks waiting for you.'}
                </Typography>
              </View>
            ) : null}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
