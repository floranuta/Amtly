import { Button, Typography, useThemeColor } from 'heroui-native';
import {
  Bell,
  BriefcaseBusiness,
  ChevronRight,
  CircleHelp,
  Info,
  Languages,
  MapPin,
  ShieldCheck,
  UserRound,
} from 'lucide-react-native';
import { ScrollView, View } from 'react-native';

import { LanguagePicker } from '@/components/amtly';
import { SoftIcon } from '@/components/amtly-ui';
import { LANGUAGE_LABELS } from '@/lib/i18n';
import { useAmtlyStore } from '@/lib/amtly-store';

const rows = [
  { icon: MapPin, title: 'Country of origin', value: 'Ukraine' },
  { icon: MapPin, title: 'Current city', value: 'Hamburg' },
  { icon: ShieldCheck, title: 'Residence status', value: '§24 (Temporary protection)' },
  { icon: BriefcaseBusiness, title: 'Employment status', value: 'Employed' },
];
export default function ProfileScreen() {
  const language = useAmtlyStore((s) => s.language);
  const foreground = useThemeColor('foreground');
  return (
    <ScrollView
      className="bg-background flex-1"
      contentContainerClassName="p-safe-offset-5 web:mx-auto web:w-full web:max-w-lg"
    >
      <View className="gap-4 pt-3 pb-10">
        <Typography.Heading type="h1" className="text-ink tracking-tighter">
          Profile
        </Typography.Heading>
        <View className="bg-info-soft flex-row items-center gap-4 rounded-2xl p-4">
          <View className="bg-hairline h-12 w-12 items-center justify-center rounded-full">
            <Typography weight="bold">TB</Typography>
          </View>
          <View>
            <Typography weight="bold">Tetiana</Typography>
            <Typography type="body-xs" color="muted">
              View and edit your information
            </Typography>
          </View>
        </View>
        <View className="border-hairline flex-row items-center gap-4 border-b py-3">
          <SoftIcon icon={Languages} size={38} />
          <View className="min-w-0 flex-1">
            <Typography weight="bold">Preferred language</Typography>
            <Typography type="body-xs" color="muted">
              {LANGUAGE_LABELS[language]}
            </Typography>
          </View>
          <LanguagePicker />
        </View>
        {rows.map((row) => (
          <View
            key={row.title}
            className="border-hairline flex-row items-center gap-4 border-b py-3"
          >
            <SoftIcon icon={row.icon} size={38} />
            <View className="min-w-0 flex-1">
              <Typography weight="bold">{row.title}</Typography>
              <Typography type="body-xs" color="muted">
                {row.value}
              </Typography>
            </View>
            <ChevronRight color={foreground} size={17} />
          </View>
        ))}
        {[
          { icon: Bell, title: 'Notifications' },
          { icon: CircleHelp, title: 'Help & Support' },
          { icon: Info, title: 'About Amtly' },
        ].map((row) => (
          <Button
            key={row.title}
            variant="ghost"
            className="border-hairline h-auto justify-start rounded-none border-b px-0 py-4"
          >
            <row.icon color={foreground} size={20} />
            <Button.Label className="flex-1 text-left">{row.title}</Button.Label>
            <ChevronRight color={foreground} size={17} />
          </Button>
        ))}
        <View className="items-center pt-3">
          <UserRound color={foreground} size={18} />
          <Typography type="body-xs" color="muted">
            Amtly demo profile
          </Typography>
        </View>
      </View>
    </ScrollView>
  );
}
