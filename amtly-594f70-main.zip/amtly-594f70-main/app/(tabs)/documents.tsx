import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { Button, Typography, useThemeColor } from 'heroui-native';
import { Camera, FileText, Image, ShieldCheck, Upload } from 'lucide-react-native';
import { useState } from 'react';
import { Alert, ScrollView, View } from 'react-native';

import type { UploadedDocument } from '@/lib/amtly-store';
import { useAmtlyStore } from '@/lib/amtly-store';

export default function DocumentsScreen() {
  const [selected, setSelected] = useState<UploadedDocument | null>(null);
  const setDocument = useAmtlyStore((state) => state.setDocument);
  const foreground = useThemeColor('foreground');
  const chooseFile = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/pdf', 'image/*'],
        copyToCacheDirectory: true,
      });
      if (!result.canceled) {
        const a = result.assets[0];
        setSelected({ name: a.name, uri: a.uri, mimeType: a.mimeType });
      }
    } catch {
      Alert.alert('That file could not be opened. Please try another one.');
    }
  };
  const chooseGallery = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        quality: 0.9,
      });
      if (!result.canceled) {
        const a = result.assets[0];
        setSelected({
          name: a.fileName ?? 'Official letter image',
          uri: a.uri,
          mimeType: a.mimeType,
        });
      }
    } catch {
      Alert.alert('That photo could not be opened. Please try another one.');
    }
  };
  const takePhoto = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Camera access is off', 'You can still choose a PDF or a gallery photo.');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.9 });
    if (!result.canceled) {
      const a = result.assets[0];
      setSelected({ name: a.fileName ?? 'Letter photo.jpg', uri: a.uri, mimeType: a.mimeType });
    }
  };
  const analyse = () => {
    if (!selected) return;
    setDocument(selected);
    router.push('/analysis');
  };
  return (
    <ScrollView
      className="bg-background flex-1"
      contentContainerClassName="p-safe-offset-5 web:mx-auto web:w-full web:max-w-lg"
    >
      <View className="gap-6 pt-3 pb-10">
        <Typography.Heading type="h3" className="text-ink">
          Understand a Letter
        </Typography.Heading>
        <View className="border-hairline min-h-56 items-center justify-center gap-3 rounded-3xl border border-dashed p-6">
          <View className="bg-paper-soft h-16 w-16 items-center justify-center rounded-2xl">
            <Upload color={foreground} size={29} />
          </View>
          <Typography weight="bold">{selected ? selected.name : 'Upload a letter'}</Typography>
          <Typography type="body-sm" color="muted">
            PDF, JPG or PNG
          </Typography>
          <Button
            className="bg-flag-gold mt-2 rounded-full px-8"
            onPress={selected ? analyse : chooseFile}
          >
            <FileText color={foreground} size={17} />
            <Button.Label className="text-ink">
              {selected ? 'Explain this letter' : 'Choose file'}
            </Button.Label>
          </Button>
        </View>
        <View className="flex-row items-center gap-3">
          <View className="bg-hairline h-px flex-1" />
          <Typography type="body-xs" color="muted">
            or
          </Typography>
          <View className="bg-hairline h-px flex-1" />
        </View>
        <Button variant="secondary" className="rounded-full" onPress={takePhoto}>
          <Camera color={foreground} size={18} />
          <Button.Label>Take a photo</Button.Label>
        </Button>
        <Button variant="secondary" className="rounded-full" onPress={chooseGallery}>
          <Image color={foreground} size={18} />
          <Button.Label>Choose from gallery</Button.Label>
        </Button>
        <View className="bg-paper-soft mt-4 flex-row items-start gap-3 rounded-2xl p-4">
          <ShieldCheck color={foreground} size={23} />
          <View className="min-w-0 flex-1">
            <Typography weight="bold">Your data is safe</Typography>
            <Typography type="body-xs" color="muted">
              Your letter stays on your device in this demo.
            </Typography>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}
