import { router } from 'expo-router';
import { Button, Typography, useThemeColor } from 'heroui-native';
import {
  Building2,
  CalendarClock,
  Check,
  ChevronLeft,
  ExternalLink,
  FileText,
  ListChecks,
  MessageCircle,
  MoreHorizontal,
  ShieldCheck,
} from 'lucide-react-native';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Linking, ScrollView, View } from 'react-native';

import { useAmtlyStore } from '@/lib/amtly-store';

const AMTLY_WEBHOOK_URL = 'https://flora-nuta.app.n8n.cloud/webhook-test/Amtly';
const REQUEST_ERROR_MESSAGE = "Sorry, Amtly couldn't process your request. Please try again.";

type AmtlyAction = {
  id: string;
  title: string;
  description: string;
};

type AmtlyDocument = {
  id: string;
  value: string;
};

type AmtlySource = {
  id: string;
  title: string;
  url: string;
};

type AmtlyData = {
  summary: string;
  actions: AmtlyAction[];
  responsibleAuthority: string;
  requiredDocuments: AmtlyDocument[];
  deadline: string | null;
  important: string;
  sources: AmtlySource[];
};

type AmtlyResponse = {
  success: boolean;
  data?: unknown;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null;
}

function isAmtlyResponse(value: unknown): value is AmtlyResponse {
  return isRecord(value) && typeof value.success === 'boolean';
}

function readString(value: unknown): string {
  return typeof value === 'string' ? value.trim() : '';
}

function createUniqueId(prefix: string, value: string, seen: Map<string, number>): string {
  const baseId = `${prefix}:${value}`;
  const occurrence = seen.get(baseId) ?? 0;
  seen.set(baseId, occurrence + 1);
  return occurrence === 0 ? baseId : `${baseId}:${occurrence}`;
}

function normalizeAmtlyData(value: unknown): AmtlyData {
  const data = isRecord(value) ? value : {};
  const actionIds = new Map<string, number>();
  const actions = Array.isArray(data.actions)
    ? data.actions.flatMap((item) => {
        if (!isRecord(item)) return [];
        const title = readString(item.title);
        const description = readString(item.description);
        const content = `${title}:${description}`;
        return title || description
          ? [{ id: createUniqueId('action', content, actionIds), title, description }]
          : [];
      })
    : [];
  const documentIds = new Map<string, number>();
  const requiredDocuments = Array.isArray(data.required_documents)
    ? data.required_documents.flatMap((item) => {
        const document = readString(item);
        return document
          ? [{ id: createUniqueId('document', document, documentIds), value: document }]
          : [];
      })
    : [];
  const sourceIds = new Map<string, number>();
  const sources = Array.isArray(data.sources)
    ? data.sources.flatMap((item) => {
        if (!isRecord(item)) return [];
        const title = readString(item.title);
        const url = readString(item.url);
        return title && url
          ? [{ id: createUniqueId('source', `${title}:${url}`, sourceIds), title, url }]
          : [];
      })
    : [];

  return {
    summary: readString(data.summary),
    actions,
    responsibleAuthority: readString(data.responsible_authority),
    requiredDocuments,
    deadline: readString(data.deadline) || null,
    important: readString(data.important),
    sources,
  };
}

export default function AskScreen() {
  const question = useAmtlyStore((state) => state.question);
  const [result, setResult] = useState<AmtlyData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const foreground = useThemeColor('foreground');

  useEffect(() => {
    const controller = new AbortController();

    const askAmtly = async () => {
      setIsLoading(true);
      setHasError(false);
      setResult(null);

      try {
        const response = await fetch(AMTLY_WEBHOOK_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: question,
            language: 'en',
            requestType: 'question',
          }),
          signal: controller.signal,
        });

        if (!response.ok) throw new Error('Amtly request failed');

        const data: unknown = await response.json();
        if (!isAmtlyResponse(data)) throw new Error('Invalid Amtly response');
        if (!data.success) {
          setHasError(true);
          return;
        }

        setResult(normalizeAmtlyData(data.data));
      } catch (error) {
        if (error instanceof Error && error.name === 'AbortError') return;
        setHasError(true);
      } finally {
        if (!controller.signal.aborted) setIsLoading(false);
      }
    };

    void askAmtly();
    return () => controller.abort();
  }, [question]);
  return (
    <ScrollView
      className="bg-background flex-1"
      contentContainerClassName="p-safe-offset-5 web:mx-auto web:w-full web:max-w-lg"
    >
      <View className="flex-row items-center justify-between py-3">
        <Button isIconOnly variant="ghost" onPress={() => router.back()}>
          <ChevronLeft color={foreground} />
        </Button>
        <Typography weight="bold">Ask Amtly</Typography>
        <Button isIconOnly variant="ghost">
          <MoreHorizontal color={foreground} />
        </Button>
      </View>
      <View className="gap-5 pt-4 pb-10">
        <View className="bg-info-soft max-w-[86%] self-end rounded-3xl rounded-tr-md p-4">
          <Typography className="text-ink leading-6">
            {question || 'I moved to Germany and started a new job. What do I need to do?'}
          </Typography>
        </View>
        <View className="flex-row items-start gap-3">
          <View className="bg-ink h-9 w-9 items-center justify-center rounded-full">
            <MessageCircle color="white" size={18} />
          </View>
          <View className="min-w-0 flex-1 gap-4">
            {isLoading ? (
              <ActivityIndicator accessibilityLabel="Loading Amtly answer" color={foreground} />
            ) : hasError ? (
              <Typography className="text-ink leading-6">{REQUEST_ERROR_MESSAGE}</Typography>
            ) : (
              <>
                {result?.summary ? (
                  <Typography className="text-ink leading-6">{result.summary}</Typography>
                ) : null}

                {result?.actions.length ? (
                  <View className="gap-3">
                    {result.actions.map((action) => (
                      <View key={action.id} className="bg-paper-soft gap-1 rounded-2xl p-4">
                        {action.title ? (
                          <Typography weight="semibold" className="text-ink">
                            {action.title}
                          </Typography>
                        ) : null}
                        {action.description ? (
                          <Typography type="body-sm" className="text-ink-muted leading-5">
                            {action.description}
                          </Typography>
                        ) : null}
                      </View>
                    ))}
                  </View>
                ) : null}

                {result?.responsibleAuthority ? (
                  <View className="gap-2">
                    <Typography weight="semibold" className="text-ink">
                      Responsible Authority
                    </Typography>
                    <View className="bg-paper-soft flex-row items-start gap-3 rounded-2xl p-4">
                      <Building2 color={foreground} size={20} />
                      <Typography
                        type="body-sm"
                        className="text-ink-muted min-w-0 flex-1 leading-5"
                      >
                        {result.responsibleAuthority}
                      </Typography>
                    </View>
                  </View>
                ) : null}

                {result?.requiredDocuments.length ? (
                  <View className="gap-2">
                    <Typography weight="semibold" className="text-ink">
                      Required Documents
                    </Typography>
                    <View className="bg-paper-soft gap-3 rounded-2xl p-4">
                      {result.requiredDocuments.map((document) => (
                        <View key={document.id} className="flex-row items-start gap-3">
                          <View className="bg-flag-red-soft h-6 w-6 items-center justify-center rounded-full">
                            <Check color={foreground} size={14} strokeWidth={2.5} />
                          </View>
                          <Typography
                            type="body-sm"
                            className="text-ink-muted min-w-0 flex-1 leading-5"
                          >
                            {document.value}
                          </Typography>
                        </View>
                      ))}
                    </View>
                  </View>
                ) : null}

                {result?.deadline ? (
                  <View className="bg-flag-red-soft flex-row items-start gap-3 rounded-2xl p-4">
                    <CalendarClock color={foreground} size={20} />
                    <View className="min-w-0 flex-1 gap-1">
                      <Typography weight="semibold" className="text-ink">
                        Deadline
                      </Typography>
                      <Typography type="body-sm" className="text-ink-muted leading-5">
                        {result.deadline}
                      </Typography>
                    </View>
                  </View>
                ) : null}

                {result?.sources.length ? (
                  <View className="gap-2">
                    <Typography weight="semibold" className="text-ink">
                      Official Sources
                    </Typography>
                    <View className="gap-1">
                      {result.sources.map((source) => (
                        <Button
                          key={source.id}
                          variant="ghost"
                          className="justify-start px-0"
                          onPress={() => void Linking.openURL(source.url)}
                        >
                          <ListChecks color={foreground} size={18} />
                          <Button.Label className="min-w-0 flex-1">{source.title}</Button.Label>
                          <ExternalLink color={foreground} size={16} />
                        </Button>
                      ))}
                    </View>
                  </View>
                ) : null}
              </>
            )}
          </View>
        </View>
        {!isLoading && !hasError && result?.important ? (
          <View className="bg-flag-gold-soft flex-row items-start gap-3 rounded-2xl p-4">
            <ShieldCheck color={foreground} size={20} />
            <Typography type="body-sm" className="text-ink-muted min-w-0 flex-1">
              {result.important}
            </Typography>
          </View>
        ) : null}
        <Button className="bg-ink h-13 rounded-full" onPress={() => router.replace('/(tabs)/home')}>
          <FileText color="white" size={18} />
          <Button.Label className="text-paper">Ask another question</Button.Label>
        </Button>
      </View>
    </ScrollView>
  );
}
