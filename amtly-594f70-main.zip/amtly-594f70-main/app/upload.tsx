import { Redirect } from 'expo-router';

export default function UploadRedirect() {
  return <Redirect href="/(tabs)/documents" />;
}
